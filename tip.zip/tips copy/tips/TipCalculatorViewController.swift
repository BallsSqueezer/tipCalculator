//
//  ViewController.swift
//  tips
//
//  Created by Hien Quang Tran on 6/4/16.
//  Copyright © 2016 Hien Tran. All rights reserved.
//

import UIKit

class TipCalculatorViewController: UIViewController{
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipControl: UISegmentedControl!
    @IBOutlet weak var twoPeopleSplitLabel: UILabel!
    @IBOutlet weak var threePeopleSplitLabel: UILabel!
    @IBOutlet weak var fourPeopleSplitLabel: UILabel!
    @IBOutlet weak var containerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        //Animations
        if amountTextField.text!.isEmpty{
            amountTextField.transform = CGAffineTransformMakeTranslation(0, view.bounds.height / 4)
            containerView.transform = CGAffineTransformMakeTranslation(0, 500)
            tipControl.transform = CGAffineTransformMakeTranslation(0, 500 - 30)
        }
        
        //load the index of tip segment
        let userDefaults = NSUserDefaults.standardUserDefaults()
        tipControl.selectedSegmentIndex = userDefaults.integerForKey("TipControlSegmentIndex")
        
        amountTextField.becomeFirstResponder()
    }

    @IBAction func onEditingChanged(sender: AnyObject) {
        let userDefaults = NSUserDefaults.standardUserDefaults()
        userDefaults.setObject(amountTextField.text, forKey: "AmountTextField")
        
        updateLabel()
        showAnimations()
    }
    
    @IBAction func onTap(sender: AnyObject) { //make the keyboard disappear when tap outsite textfield
        if let text = amountTextField.text{
            if !text.isEmpty {
                amountTextField.resignFirstResponder()
            }
        }
    }
    
    
    // MARK: - Helper Functions
    func updateLabel(){
        let tipPercentages = [0.18, 0.2, 0.22]
        let tipPercentage = tipPercentages[tipControl.selectedSegmentIndex]
        
        if let amount = amountTextField.text{
            let billAmount = (amount as NSString).doubleValue
            let tip = billAmount * tipPercentage
            let total = billAmount + tip
            
            //change format of the label to currency
            let formatter = NSNumberFormatter()
            formatter.numberStyle = .CurrencyStyle
            
            tipLabel.text = formatter.stringFromNumber(tip)
            totalLabel.text = formatter.stringFromNumber(total)
            twoPeopleSplitLabel.text = formatter.stringFromNumber(total / 2)
            threePeopleSplitLabel.text = formatter.stringFromNumber(total / 3)
            fourPeopleSplitLabel.text = formatter.stringFromNumber(total / 4)
        }
    }
    
    func showAnimations(){
        //animation when user starts typing
        if amountTextField.editing{
            UIView.animateWithDuration(0.5, delay: 0, options: UIViewAnimationOptions.CurveEaseOut, animations: {
                self.amountTextField.transform = CGAffineTransformIdentity
                self.containerView.transform = CGAffineTransformIdentity
                self.tipControl.transform = CGAffineTransformIdentity
            }, completion: nil)
        }
        
        //animations when there's nothing in the text field
        if let text = amountTextField.text{
            if text.isEmpty{
                UIView.animateWithDuration(0.5, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                    self.amountTextField.transform = CGAffineTransformMakeTranslation(0, self.view.bounds.height / 4)
                    self.containerView.transform = CGAffineTransformMakeTranslation(0, 500)
                    self.tipControl.transform = CGAffineTransformMakeTranslation(0, 500 - 30)
                }, completion: nil)
            }
        }
    }
}

