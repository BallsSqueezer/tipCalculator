//
//  SettingViewController.swift
//  tips
//
//  Created by Hien Quang Tran on 6/4/16.
//  Copyright © 2016 Hien Tran. All rights reserved.
//

import UIKit

class SettingViewController: UIViewController {
    @IBOutlet weak var tipControl: UISegmentedControl!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let userDefaults = NSUserDefaults.standardUserDefaults()
        tipControl.selectedSegmentIndex = userDefaults.integerForKey("TipControlSegmentIndex")
    }

    @IBAction func TipPercentageDefault(sender: UISegmentedControl) {
        let userDefaults = NSUserDefaults.standardUserDefaults()
        userDefaults.setInteger(tipControl.selectedSegmentIndex, forKey: "TipControlSegmentIndex")
        userDefaults.synchronize()
    }
}
